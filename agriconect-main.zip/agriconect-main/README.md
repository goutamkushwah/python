# Online Farm Veggies - Web Application

A complete farm-to-consumer marketplace web application built with React, TypeScript, and Supabase.

## Features

### For Customers
- Browse available products with search and filter
- Add products to cart
- Place orders with Cash on Delivery (COD) or Online Payment
- View order history and status

### For Farmers
- Add, edit, and delete products
- Manage product inventory
- Track product sales
- Update product availability

### For Admin
- Dashboard with system analytics
- View total users, products, and orders
- Monitor revenue and pending orders
- Track system performance metrics

## Technology Stack

### Frontend
- **React 18** - UI library
- **TypeScript** - Type safety
- **Tailwind CSS** - Styling
- **Lucide React** - Icons
- **Vite** - Build tool

### Backend & Database
- **Supabase** - Backend as a Service
  - PostgreSQL database
  - Authentication
  - Row Level Security (RLS)
  - Real-time subscriptions

## Project Structure

```
src/
├── components/
│   ├── admin/           # Admin dashboard components
│   ├── auth/            # Login and Signup components
│   ├── customer/        # Customer interface (products, cart)
│   ├── farmer/          # Farmer dashboard and product management
│   └── layout/          # Shared layout components (Navbar, Layout)
├── contexts/
│   └── AuthContext.tsx  # Authentication context provider
├── lib/
│   └── supabase.ts      # Supabase client configuration
├── types/
│   └── index.ts         # TypeScript type definitions
├── App.tsx              # Main application component
└── main.tsx             # Application entry point
```

## Setup Instructions

### Prerequisites
- Node.js 18+ and npm
- Supabase account

### Installation

1. **Clone the repository**
   ```bash
   git clone <repository-url>
   cd project
   ```

2. **Install dependencies**
   ```bash
   npm install
   ```

3. **Configure Environment Variables**

   The `.env` file should contain:
   ```
   VITE_SUPABASE_URL=your-supabase-url
   VITE_SUPABASE_ANON_KEY=your-supabase-anon-key
   ```

4. **Set up the Database**

   - Go to your Supabase project SQL Editor
   - Run the migration script from `DATABASE_SETUP.md`
   - This will create all necessary tables and security policies

5. **Run the Development Server**
   ```bash
   npm run dev
   ```

   The application will be available at `http://localhost:5173`

6. **Build for Production**
   ```bash
   npm run build
   ```

## Usage Guide

### First Time Setup

1. **Create Admin Account**
   - Sign up with role "Customer" (you'll need to manually change this in the database to "admin" for the first admin)
   - Or directly insert an admin user in the `user_roles` table

2. **Create Farmer Account**
   - Sign up with role "Farmer"
   - Add products through the Farmer Dashboard

3. **Create Customer Account**
   - Sign up with role "Customer"
   - Browse products and place orders

### User Roles

**Admin**
- Full system access
- View analytics and statistics
- Monitor all users, products, and orders

**Farmer**
- Manage own products (CRUD operations)
- View product performance
- Update inventory

**Customer**
- Browse all available products
- Add items to cart
- Place orders
- View order history

## Database Schema

### Tables
- `user_roles` - User profiles with role information
- `products` - Product listings
- `orders` - Customer orders
- `order_items` - Individual items in orders

See `DATABASE_SETUP.md` for detailed schema and setup instructions.

## Security

- **Authentication**: Supabase Auth with email/password
- **Authorization**: Role-based access control (RBAC)
- **Row Level Security**: Database-level security policies
- **Data Isolation**: Users can only access their own data

## API Integration

The application uses Supabase client library for all backend operations:
- Authentication
- Database queries
- Real-time updates

## Development

### Available Scripts

- `npm run dev` - Start development server
- `npm run build` - Build for production
- `npm run preview` - Preview production build
- `npm run lint` - Run ESLint
- `npm run typecheck` - Run TypeScript type checking

### Code Style
- TypeScript strict mode enabled
- ESLint for code quality
- Tailwind CSS for styling
- Component-based architecture

## Deployment

### Frontend Deployment
The application can be deployed to:
- Vercel
- Netlify
- Firebase Hosting
- Any static hosting service

### Database
- Already hosted on Supabase
- No additional setup required
- Automatic backups and scaling

## Features to Add (Future Enhancements)

- Order tracking with status updates
- Email notifications
- Product reviews and ratings
- Advanced search with filters
- Image upload for products
- Payment gateway integration (Razorpay/Stripe)
- Mobile responsive improvements
- Farmer earnings dashboard
- Customer wishlist
- Promotional codes and discounts

## Troubleshooting

### Database Connection Issues
- Verify environment variables in `.env`
- Check Supabase project status
- Ensure database migrations are applied

### Authentication Issues
- Clear browser cache and cookies
- Check Supabase Auth settings
- Verify RLS policies are correctly set

### Build Errors
- Run `npm install` to ensure all dependencies are installed
- Check for TypeScript errors with `npm run typecheck`
- Clear node_modules and reinstall if needed

## License

MIT License

## Contact

For questions or support, please contact the development team.
