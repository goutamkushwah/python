export type UserRole = 'admin' | 'farmer' | 'customer';

export interface User {
  id: string;
  email: string;
  full_name: string;
  role: UserRole;
  phone: string;
  address?: string;
}

export interface Product {
  id: string;
  farmer_id: string;
  farmer_name?: string;
  name: string;
  description: string;
  category: string;
  price: number;
  unit: string;
  stock_quantity: number;
  image_url?: string;
  status: 'available' | 'out_of_stock';
  created_at: string;
}

export interface CartItem {
  id: string;
  product: Product;
  quantity: number;
}

export interface OrderItem {
  id: string;
  product_id: string;
  product_name: string;
  quantity: number;
  price: number;
}

export interface Order {
  id: string;
  customer_id: string;
  customer_name?: string;
  items: OrderItem[];
  total_amount: number;
  payment_method: 'cod' | 'online';
  payment_status: 'pending' | 'completed' | 'failed';
  order_status: 'pending' | 'confirmed' | 'shipped' | 'delivered' | 'cancelled';
  delivery_address: string;
  created_at: string;
}
