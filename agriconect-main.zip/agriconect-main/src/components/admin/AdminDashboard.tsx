import React, { useState, useEffect } from 'react';
import { Users, Package, ShoppingBag, DollarSign, TrendingUp } from 'lucide-react';
import { supabase } from '../../lib/supabase';

interface Stats {
  totalUsers: number;
  totalFarmers: number;
  totalCustomers: number;
  totalProducts: number;
  totalOrders: number;
  totalRevenue: number;
  pendingOrders: number;
}

export const AdminDashboard: React.FC = () => {
  const [stats, setStats] = useState<Stats>({
    totalUsers: 0,
    totalFarmers: 0,
    totalCustomers: 0,
    totalProducts: 0,
    totalOrders: 0,
    totalRevenue: 0,
    pendingOrders: 0,
  });
  const [loading, setLoading] = useState(true);
  const [recentOrders, setRecentOrders] = useState<any[]>([]);

  useEffect(() => {
    loadDashboardData();
  }, []);

  const loadDashboardData = async () => {
    try {
      const [usersRes, productsRes, ordersRes] = await Promise.all([
        supabase.from('user_roles').select('role'),
        supabase.from('products').select('id'),
        supabase.from('orders').select('*, order_items(*)'),
      ]);

      const users = usersRes.data || [];
      const products = productsRes.data || [];
      const orders = ordersRes.data || [];

      const totalRevenue = orders.reduce((sum, order) => sum + parseFloat(order.total_amount || 0), 0);
      const pendingOrders = orders.filter(order => order.order_status === 'pending').length;

      setStats({
        totalUsers: users.length,
        totalFarmers: users.filter(u => u.role === 'farmer').length,
        totalCustomers: users.filter(u => u.role === 'customer').length,
        totalProducts: products.length,
        totalOrders: orders.length,
        totalRevenue,
        pendingOrders,
      });

      setRecentOrders(orders.slice(0, 5));
    } catch (error) {
      console.error('Error loading dashboard data:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return <div className="text-center py-12">Loading dashboard...</div>;
  }

  return (
    <div>
      <h1 className="text-3xl font-bold text-gray-800 mb-8">Admin Dashboard</h1>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <div className="bg-gradient-to-br from-blue-500 to-blue-600 text-white rounded-lg shadow-md p-6">
          <div className="flex items-center justify-between mb-4">
            <Users className="w-12 h-12 opacity-80" />
            <span className="text-3xl font-bold">{stats.totalUsers}</span>
          </div>
          <h3 className="text-lg font-semibold">Total Users</h3>
          <p className="text-sm opacity-80">
            {stats.totalFarmers} Farmers, {stats.totalCustomers} Customers
          </p>
        </div>

        <div className="bg-gradient-to-br from-green-500 to-green-600 text-white rounded-lg shadow-md p-6">
          <div className="flex items-center justify-between mb-4">
            <Package className="w-12 h-12 opacity-80" />
            <span className="text-3xl font-bold">{stats.totalProducts}</span>
          </div>
          <h3 className="text-lg font-semibold">Total Products</h3>
          <p className="text-sm opacity-80">Available in marketplace</p>
        </div>

        <div className="bg-gradient-to-br from-orange-500 to-orange-600 text-white rounded-lg shadow-md p-6">
          <div className="flex items-center justify-between mb-4">
            <ShoppingBag className="w-12 h-12 opacity-80" />
            <span className="text-3xl font-bold">{stats.totalOrders}</span>
          </div>
          <h3 className="text-lg font-semibold">Total Orders</h3>
          <p className="text-sm opacity-80">{stats.pendingOrders} pending orders</p>
        </div>

        <div className="bg-gradient-to-br from-emerald-500 to-emerald-600 text-white rounded-lg shadow-md p-6">
          <div className="flex items-center justify-between mb-4">
            <DollarSign className="w-12 h-12 opacity-80" />
            <span className="text-3xl font-bold">₹{stats.totalRevenue.toFixed(0)}</span>
          </div>
          <h3 className="text-lg font-semibold">Total Revenue</h3>
          <p className="text-sm opacity-80">All time earnings</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white rounded-lg shadow-md p-6">
          <h2 className="text-xl font-bold text-gray-800 mb-4 flex items-center">
            <TrendingUp className="w-6 h-6 mr-2 text-green-600" />
            Recent Orders
          </h2>
          {recentOrders.length === 0 ? (
            <p className="text-gray-500 text-center py-8">No orders yet</p>
          ) : (
            <div className="space-y-3">
              {recentOrders.map(order => (
                <div key={order.id} className="border-b pb-3 last:border-b-0">
                  <div className="flex justify-between items-start mb-1">
                    <span className="font-semibold text-gray-700">Order #{order.id.slice(0, 8)}</span>
                    <span className={`text-xs px-2 py-1 rounded ${
                      order.order_status === 'delivered'
                        ? 'bg-green-100 text-green-800'
                        : order.order_status === 'cancelled'
                        ? 'bg-red-100 text-red-800'
                        : 'bg-yellow-100 text-yellow-800'
                    }`}>
                      {order.order_status}
                    </span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-500">
                      {new Date(order.created_at).toLocaleDateString()}
                    </span>
                    <span className="font-semibold text-green-600">₹{order.total_amount}</span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        <div className="bg-white rounded-lg shadow-md p-6">
          <h2 className="text-xl font-bold text-gray-800 mb-4">Quick Stats</h2>
          <div className="space-y-4">
            <div className="flex justify-between items-center py-3 border-b">
              <span className="text-gray-600">Average Order Value</span>
              <span className="font-bold text-gray-800">
                ₹{stats.totalOrders > 0 ? (stats.totalRevenue / stats.totalOrders).toFixed(2) : '0.00'}
              </span>
            </div>
            <div className="flex justify-between items-center py-3 border-b">
              <span className="text-gray-600">Products per Farmer</span>
              <span className="font-bold text-gray-800">
                {stats.totalFarmers > 0 ? (stats.totalProducts / stats.totalFarmers).toFixed(1) : '0'}
              </span>
            </div>
            <div className="flex justify-between items-center py-3 border-b">
              <span className="text-gray-600">Orders per Customer</span>
              <span className="font-bold text-gray-800">
                {stats.totalCustomers > 0 ? (stats.totalOrders / stats.totalCustomers).toFixed(1) : '0'}
              </span>
            </div>
            <div className="flex justify-between items-center py-3">
              <span className="text-gray-600">Pending Orders Rate</span>
              <span className="font-bold text-gray-800">
                {stats.totalOrders > 0 ? ((stats.pendingOrders / stats.totalOrders) * 100).toFixed(1) : '0'}%
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
