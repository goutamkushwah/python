import React, { useState } from 'react';
import { Product, CartItem } from '../../types';
import { ProductList } from './ProductList';
import { Cart } from './Cart';
import { ShoppingCart } from 'lucide-react';

export const CustomerDashboard: React.FC = () => {
  const [cart, setCart] = useState<CartItem[]>([]);
  const [showCart, setShowCart] = useState(false);

  const handleAddToCart = (product: Product) => {
    setCart(prevCart => {
      const existingItem = prevCart.find(item => item.product.id === product.id);

      if (existingItem) {
        return prevCart.map(item =>
          item.product.id === product.id
            ? { ...item, quantity: Math.min(item.quantity + 1, product.stock_quantity) }
            : item
        );
      }

      return [...prevCart, {
        id: `cart-${Date.now()}-${product.id}`,
        product,
        quantity: 1,
      }];
    });
  };

  const handleUpdateQuantity = (itemId: string, quantity: number) => {
    setCart(prevCart =>
      prevCart.map(item =>
        item.id === itemId ? { ...item, quantity } : item
      )
    );
  };

  const handleRemoveItem = (itemId: string) => {
    setCart(prevCart => prevCart.filter(item => item.id !== itemId));
  };

  const handleClearCart = () => {
    if (confirm('Are you sure you want to clear the cart?')) {
      setCart([]);
    }
  };

  return (
    <div>
      <div className="mb-6 flex items-center justify-between">
        <h1 className="text-3xl font-bold text-gray-800">Browse Products</h1>
        <button
          onClick={() => setShowCart(!showCart)}
          className="bg-green-600 text-white py-2 px-4 rounded-md hover:bg-green-700 flex items-center gap-2"
        >
          <ShoppingCart className="w-5 h-5" />
          Cart ({cart.length})
        </button>
      </div>

      {showCart ? (
        <Cart
          cart={cart}
          onUpdateQuantity={handleUpdateQuantity}
          onRemoveItem={handleRemoveItem}
          onClearCart={handleClearCart}
        />
      ) : (
        <ProductList onAddToCart={handleAddToCart} />
      )}
    </div>
  );
};
