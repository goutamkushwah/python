import React from 'react';
import { useAuth } from '../../contexts/AuthContext';
import { ShoppingCart, LogOut, User, Package, BarChart3, Sprout } from 'lucide-react';

export const Navbar: React.FC = () => {
  const { user, signOut } = useAuth();

  const handleSignOut = async () => {
    try {
      await signOut();
    } catch (error) {
      console.error('Error signing out:', error);
    }
  };

  return (
    <nav className="bg-green-700 text-white shadow-lg">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center">
            <Sprout className="w-8 h-8 mr-2" />
            <span className="text-xl font-bold">Online Farm Veggies</span>
          </div>

          {user && (
            <div className="flex items-center space-x-6">
              <div className="flex items-center space-x-2">
                <User className="w-5 h-5" />
                <span className="font-medium">{user.full_name}</span>
                <span className="text-xs bg-green-600 px-2 py-1 rounded uppercase">
                  {user.role}
                </span>
              </div>

              {user.role === 'customer' && (
                <a href="#cart" className="flex items-center hover:text-green-200">
                  <ShoppingCart className="w-5 h-5 mr-1" />
                  Cart
                </a>
              )}

              {user.role === 'farmer' && (
                <a href="#products" className="flex items-center hover:text-green-200">
                  <Package className="w-5 h-5 mr-1" />
                  My Products
                </a>
              )}

              {user.role === 'admin' && (
                <a href="#dashboard" className="flex items-center hover:text-green-200">
                  <BarChart3 className="w-5 h-5 mr-1" />
                  Dashboard
                </a>
              )}

              <button
                onClick={handleSignOut}
                className="flex items-center bg-green-600 hover:bg-green-800 px-4 py-2 rounded"
              >
                <LogOut className="w-4 h-4 mr-1" />
                Sign Out
              </button>
            </div>
          )}
        </div>
      </div>
    </nav>
  );
};
