import { useState } from 'react';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import { Layout } from './components/layout/Layout';
import { Login } from './components/auth/Login';
import { Signup } from './components/auth/Signup';
import { CustomerDashboard } from './components/customer/CustomerDashboard';
import { FarmerDashboard } from './components/farmer/FarmerDashboard';
import { AdminDashboard } from './components/admin/AdminDashboard';

function AppContent() {
  const { user, loading } = useAuth();
  const [showLogin, setShowLogin] = useState(true);

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-100 flex items-center justify-center">
        <div className="text-center">
          <div className="inline-block animate-spin rounded-full h-12 w-12 border-b-2 border-green-600"></div>
          <p className="mt-4 text-gray-600">Loading...</p>
        </div>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-green-50 to-green-100 flex items-center justify-center p-4">
        {showLogin ? (
          <Login onToggleForm={() => setShowLogin(false)} />
        ) : (
          <Signup onToggleForm={() => setShowLogin(true)} />
        )}
      </div>
    );
  }

  return (
    <Layout>
      {user.role === 'customer' && <CustomerDashboard />}
      {user.role === 'farmer' && <FarmerDashboard />}
      {user.role === 'admin' && <AdminDashboard />}
    </Layout>
  );
}

function App() {
  return (
    <AuthProvider>
      <AppContent />
    </AuthProvider>
  );
}

export default App;
