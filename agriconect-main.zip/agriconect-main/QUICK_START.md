# Quick Start Guide - Online Farm Veggies

## Step 1: Database Setup

1. Open your Supabase project at https://supabase.com
2. Navigate to the SQL Editor
3. Copy and paste the following SQL migration script:

```sql
-- Create user_roles table
CREATE TABLE IF NOT EXISTS user_roles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL UNIQUE,
  role text NOT NULL CHECK (role IN ('admin', 'farmer', 'customer')),
  full_name text NOT NULL,
  email text NOT NULL,
  phone text NOT NULL,
  address text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE user_roles ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own profile"
  ON user_roles FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can update own profile"
  ON user_roles FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can insert own profile"
  ON user_roles FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE INDEX IF NOT EXISTS idx_user_roles_user_id ON user_roles(user_id);
CREATE INDEX IF NOT EXISTS idx_user_roles_role ON user_roles(role);

-- Create products table
CREATE TABLE IF NOT EXISTS products (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  farmer_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  name text NOT NULL,
  description text NOT NULL,
  category text NOT NULL,
  price numeric NOT NULL CHECK (price >= 0),
  unit text NOT NULL,
  stock_quantity numeric NOT NULL DEFAULT 0 CHECK (stock_quantity >= 0),
  image_url text,
  status text NOT NULL DEFAULT 'available' CHECK (status IN ('available', 'out_of_stock')),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE products ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view available products"
  ON products FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Farmers can insert own products"
  ON products FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = farmer_id);

CREATE POLICY "Farmers can update own products"
  ON products FOR UPDATE
  TO authenticated
  USING (auth.uid() = farmer_id)
  WITH CHECK (auth.uid() = farmer_id);

CREATE POLICY "Farmers can delete own products"
  ON products FOR DELETE
  TO authenticated
  USING (auth.uid() = farmer_id);

CREATE INDEX IF NOT EXISTS idx_products_farmer_id ON products(farmer_id);
CREATE INDEX IF NOT EXISTS idx_products_status ON products(status);

-- Create orders table
CREATE TABLE IF NOT EXISTS orders (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  customer_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  total_amount numeric NOT NULL CHECK (total_amount >= 0),
  payment_method text NOT NULL CHECK (payment_method IN ('cod', 'online')),
  payment_status text NOT NULL DEFAULT 'pending' CHECK (payment_status IN ('pending', 'completed', 'failed')),
  order_status text NOT NULL DEFAULT 'pending' CHECK (order_status IN ('pending', 'confirmed', 'shipped', 'delivered', 'cancelled')),
  delivery_address text NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE orders ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Customers can view own orders"
  ON orders FOR SELECT
  TO authenticated
  USING (auth.uid() = customer_id);

CREATE POLICY "Customers can insert own orders"
  ON orders FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = customer_id);

CREATE INDEX IF NOT EXISTS idx_orders_customer_id ON orders(customer_id);
CREATE INDEX IF NOT EXISTS idx_orders_status ON orders(order_status);

-- Create order_items table
CREATE TABLE IF NOT EXISTS order_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id uuid REFERENCES orders(id) ON DELETE CASCADE NOT NULL,
  product_id uuid REFERENCES products(id) NOT NULL,
  quantity numeric NOT NULL CHECK (quantity > 0),
  price numeric NOT NULL CHECK (price >= 0),
  created_at timestamptz DEFAULT now()
);

ALTER TABLE order_items ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view order items of their orders"
  ON order_items FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM orders
      WHERE orders.id = order_items.order_id
      AND orders.customer_id = auth.uid()
    )
  );

CREATE POLICY "Users can insert order items"
  ON order_items FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM orders
      WHERE orders.id = order_items.order_id
      AND orders.customer_id = auth.uid()
    )
  );

CREATE INDEX IF NOT EXISTS idx_order_items_order_id ON order_items(order_id);
CREATE INDEX IF NOT EXISTS idx_order_items_product_id ON order_items(product_id);
```

4. Click "Run" to execute the script

## Step 2: Configure Supabase Authentication

1. In your Supabase project, go to Authentication > Settings
2. Disable "Confirm email" (for easier testing)
   - Set "Enable email confirmations" to OFF
3. Save the settings

## Step 3: Start the Application

The application is already running! You should see it in your browser.

## Step 4: Create Test Accounts

### Create a Farmer Account
1. Click "Sign up" on the login page
2. Fill in the form:
   - Full Name: John Farmer
   - Email: farmer@test.com
   - Phone: 1234567890
   - Role: Farmer
   - Password: test123
3. Sign up and you'll be logged in as a farmer

### Add Some Products (as Farmer)
1. Click "Add Product"
2. Add products like:
   - Name: Fresh Tomatoes
   - Category: Vegetables
   - Price: 60
   - Unit: kg
   - Stock: 100
   - Description: Organic red tomatoes

### Create a Customer Account
1. Sign out
2. Sign up again with:
   - Full Name: Jane Customer
   - Email: customer@test.com
   - Phone: 0987654321
   - Role: Customer
   - Password: test123

### Place an Order (as Customer)
1. Browse products
2. Add items to cart
3. Click "Cart" button
4. Proceed to checkout
5. Enter delivery address
6. Select payment method (COD or Online)
7. Place order

### Create an Admin Account
1. Sign up with:
   - Full Name: Admin User
   - Email: admin@test.com
   - Role: Customer (we'll change this manually)
2. Go to Supabase Dashboard > Table Editor > user_roles
3. Find the admin user and change role from 'customer' to 'admin'
4. Refresh the application to see admin dashboard

## Application Features

### Customer Features
- Browse all available products
- Search and filter by category
- Add products to cart
- Manage cart quantities
- Place orders with COD or online payment
- View order summary

### Farmer Features
- Add new products
- Edit existing products
- Delete products
- Manage inventory
- Update product status

### Admin Features
- View system statistics
- Monitor total users, farmers, customers
- Track total products and orders
- View total revenue
- See recent orders
- Access analytics dashboard

## Troubleshooting

### "No products available"
- Make sure you're logged in as a farmer and have added products

### Authentication errors
- Clear browser cache and cookies
- Check that email confirmation is disabled in Supabase
- Verify .env variables are correct

### Database errors
- Ensure all SQL migrations were run successfully
- Check Supabase project is active
- Verify RLS policies are correctly set

## Next Steps

1. Customize the product categories
2. Add product images (use URLs from free stock photo sites)
3. Test the complete order flow
4. Explore the admin dashboard
5. Invite team members to test different roles

## Support

For detailed documentation, see:
- README.md - Complete project documentation
- DATABASE_SETUP.md - Detailed database schema information
