# Database Setup Guide

## Overview
This application uses Supabase (PostgreSQL) as its database. The database has been configured with the connection details in the `.env` file.

## Database Schema

### Tables

#### 1. user_roles
Extends Supabase auth.users with role and profile information.

```sql
- id (uuid, primary key)
- user_id (uuid, references auth.users) - unique
- role (text) - 'admin', 'farmer', or 'customer'
- full_name (text)
- email (text)
- phone (text)
- address (text, nullable)
- created_at (timestamptz)
- updated_at (timestamptz)
```

#### 2. products
Stores product listings created by farmers.

```sql
- id (uuid, primary key)
- farmer_id (uuid, references user_roles.user_id)
- name (text)
- description (text)
- category (text) - e.g., 'Vegetables', 'Fruits'
- price (numeric)
- unit (text) - e.g., 'kg', 'dozen'
- stock_quantity (numeric)
- image_url (text, nullable)
- status (text) - 'available' or 'out_of_stock'
- created_at (timestamptz)
- updated_at (timestamptz)
```

#### 3. orders
Stores customer orders.

```sql
- id (uuid, primary key)
- customer_id (uuid, references user_roles.user_id)
- total_amount (numeric)
- payment_method (text) - 'cod' or 'online'
- payment_status (text) - 'pending', 'completed', or 'failed'
- order_status (text) - 'pending', 'confirmed', 'shipped', 'delivered', or 'cancelled'
- delivery_address (text)
- created_at (timestamptz)
- updated_at (timestamptz)
```

#### 4. order_items
Stores individual items within orders.

```sql
- id (uuid, primary key)
- order_id (uuid, references orders)
- product_id (uuid, references products)
- quantity (numeric)
- price (numeric)
- created_at (timestamptz)
```

## SQL Migration Script

Run this script in your Supabase SQL editor to set up the database:

```sql
-- Create user_roles table
CREATE TABLE IF NOT EXISTS user_roles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL UNIQUE,
  role text NOT NULL CHECK (role IN ('admin', 'farmer', 'customer')),
  full_name text NOT NULL,
  email text NOT NULL,
  phone text NOT NULL,
  address text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE user_roles ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own profile"
  ON user_roles FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can update own profile"
  ON user_roles FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can insert own profile"
  ON user_roles FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE INDEX IF NOT EXISTS idx_user_roles_user_id ON user_roles(user_id);
CREATE INDEX IF NOT EXISTS idx_user_roles_role ON user_roles(role);

-- Create products table
CREATE TABLE IF NOT EXISTS products (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  farmer_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  name text NOT NULL,
  description text NOT NULL,
  category text NOT NULL,
  price numeric NOT NULL CHECK (price >= 0),
  unit text NOT NULL,
  stock_quantity numeric NOT NULL DEFAULT 0 CHECK (stock_quantity >= 0),
  image_url text,
  status text NOT NULL DEFAULT 'available' CHECK (status IN ('available', 'out_of_stock')),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE products ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view available products"
  ON products FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Farmers can insert own products"
  ON products FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = farmer_id);

CREATE POLICY "Farmers can update own products"
  ON products FOR UPDATE
  TO authenticated
  USING (auth.uid() = farmer_id)
  WITH CHECK (auth.uid() = farmer_id);

CREATE POLICY "Farmers can delete own products"
  ON products FOR DELETE
  TO authenticated
  USING (auth.uid() = farmer_id);

CREATE INDEX IF NOT EXISTS idx_products_farmer_id ON products(farmer_id);
CREATE INDEX IF NOT EXISTS idx_products_status ON products(status);

-- Create orders table
CREATE TABLE IF NOT EXISTS orders (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  customer_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  total_amount numeric NOT NULL CHECK (total_amount >= 0),
  payment_method text NOT NULL CHECK (payment_method IN ('cod', 'online')),
  payment_status text NOT NULL DEFAULT 'pending' CHECK (payment_status IN ('pending', 'completed', 'failed')),
  order_status text NOT NULL DEFAULT 'pending' CHECK (order_status IN ('pending', 'confirmed', 'shipped', 'delivered', 'cancelled')),
  delivery_address text NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE orders ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Customers can view own orders"
  ON orders FOR SELECT
  TO authenticated
  USING (auth.uid() = customer_id);

CREATE POLICY "Customers can insert own orders"
  ON orders FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = customer_id);

CREATE INDEX IF NOT EXISTS idx_orders_customer_id ON orders(customer_id);
CREATE INDEX IF NOT EXISTS idx_orders_status ON orders(order_status);

-- Create order_items table
CREATE TABLE IF NOT EXISTS order_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id uuid REFERENCES orders(id) ON DELETE CASCADE NOT NULL,
  product_id uuid REFERENCES products(id) NOT NULL,
  quantity numeric NOT NULL CHECK (quantity > 0),
  price numeric NOT NULL CHECK (price >= 0),
  created_at timestamptz DEFAULT now()
);

ALTER TABLE order_items ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view order items of their orders"
  ON order_items FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM orders
      WHERE orders.id = order_items.order_id
      AND orders.customer_id = auth.uid()
    )
  );

CREATE POLICY "Users can insert order items"
  ON order_items FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM orders
      WHERE orders.id = order_items.order_id
      AND orders.customer_id = auth.uid()
    )
  );

CREATE INDEX IF NOT EXISTS idx_order_items_order_id ON order_items(order_id);
CREATE INDEX IF NOT EXISTS idx_order_items_product_id ON order_items(product_id);
```

## Sample Data (Optional)

After setting up the schema, you can add sample data for testing:

```sql
-- Note: You'll need to create users through the application first,
-- then use their IDs in the sample data below

-- Sample products (replace farmer_id with actual user IDs)
INSERT INTO products (farmer_id, name, description, category, price, unit, stock_quantity, status) VALUES
  ('FARMER_USER_ID_HERE', 'Fresh Tomatoes', 'Organic red tomatoes', 'Vegetables', 60, 'kg', 100, 'available'),
  ('FARMER_USER_ID_HERE', 'Green Apples', 'Crisp and sweet green apples', 'Fruits', 120, 'kg', 50, 'available'),
  ('FARMER_USER_ID_HERE', 'Carrots', 'Fresh orange carrots', 'Vegetables', 40, 'kg', 80, 'available');
```

## Security Features

1. **Row Level Security (RLS)**: Enabled on all tables
2. **Authentication**: Required for all operations
3. **Data Isolation**: Users can only access their own data
4. **Role-based Access**: Different permissions for admin, farmer, and customer roles

## Next Steps

1. Run the migration script in Supabase SQL Editor
2. Create your first admin user through the application
3. Test the application with different user roles
4. Add sample products as a farmer
5. Place test orders as a customer
